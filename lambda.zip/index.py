def lambda_handler(event, context):
    # Your logic here, like interacting with AWS services or returning chatbot responses
    return {
        'statusCode': 200,
        'body': 'Cloud Cost Optimization Bot is working!'
    }